package com.mydemo.spring.controladores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import com.mydemo.spring.modelo.Autor;
import com.mydemo.spring.servicios.AutorService;
import com.mydemo.spring.upload.storage.StorageService;

@Controller
public class AutorController {

	@Autowired
	private AutorService servicio;

	@Autowired
	private StorageService storageService;

	@GetMapping({ "/", "/autor/list" })
	public String listado(Model model) {
		model.addAttribute("listaAutores", servicio.findAll());
		return "list";
	}

	@GetMapping("/autor/new")
	public String nuevoAutorForm(Model model) {
		model.addAttribute("autorForm", new Autor());
		return "form";
	}

	@PostMapping("/autor/new/submit")
	public String nuevoAutorSubmit(@Valid @ModelAttribute("autorForm") Autor nuevoAutor, BindingResult bindingResult,
			@RequestParam("file") MultipartFile file) {

		if (bindingResult.hasErrors()) {
			return "form";
		} else {
			if (!file.isEmpty()) {
				String avatar = storageService.store(file, nuevoAutor.getId());
				nuevoAutor.setImagen(MvcUriComponentsBuilder.fromMethodName(AutorController.class, "serveFile", avatar)
						.build().toUriString());
			}
			servicio.add(nuevoAutor);
			return "redirect:/autor/list";
		}
	}

	@GetMapping("/autor/edit/{id}")
	public String editarAutorForm(@PathVariable long id, Model model) {
		Autor autor = servicio.findById(id);
		if (autor != null) {
			model.addAttribute("autorForm", autor);
			return "form";
		} else
			return "redirect:/autor/new";
	}

	@PostMapping("/autor/edit/submit")
	public String editarAutorSubmit(@Valid @ModelAttribute("autorForm") Autor nuevoAutor, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "form";
		} else {
			servicio.edit(nuevoAutor);
			return "redirect:/autor/list";
		}
	}

	@GetMapping("/files/{filename:.+}")
	@ResponseBody
	public ResponseEntity<Resource> serveFile(@PathVariable String filename) {
		Resource file = storageService.loadAsResource(filename);
		return ResponseEntity.ok().body(file);
	}

}
