package com.mydemo.spring.servicios;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.mydemo.spring.modelo.Libro;
import com.mydemo.spring.repositorios.LibroRepository;

@Primary
@Service("libroServiceDB")
public abstract class LibroServiceDB implements LibroService {

	@Autowired
	private LibroRepository repositorio;

	@Override
	public Libro add(Libro l) {
		return repositorio.save(l);
	}

	@Override
	public List<Libro> findAll() {
		return repositorio.findAll();
	}

	@Override
	public Libro findById(Long id) {
		return repositorio.findById(id).orElse(null);
	}

	@Override
	public Libro findByISBN(long ISBN) {
		return ((Optional<Libro>) repositorio.findByISBN(ISBN)).orElse(null);
	}

	@Override
	public Libro edit(Libro l) {
		return repositorio.save(l);
	}

	@Override
	public void delete(Libro l) {
		repositorio.delete(l);
	}

}
