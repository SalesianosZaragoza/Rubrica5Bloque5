package com.mydemo.spring.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

import org.springframework.data.annotation.Id;

@Entity
public class Libro {

	@Id
	private long id;
	@ISBN
	@GeneratedValue
	private long ISBN;

	@Column(nullable = false)
	// @NotEmpty
	private String titulo;

	private String autor;

	private Integer autorId;

	private String portada;

	public Libro(int i, String string, String string2, String string3, Object object) {

	}

	public Libro() {
		super();
		this.id = id;
		ISBN = ISBN;
		this.titulo = titulo;
		this.autor = autor;
		this.autorId = autorId;
		this.portada = portada;
	}

	public long getISBN() {
		return ISBN;
	}

	public void setISBN(long iSBN) {
		ISBN = iSBN;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public Integer getAutorId() {
		return autorId;
	}

	public void setAutorId(Integer autorId) {
		this.autorId = autorId;
	}

	public String getPortada() {
		return portada;
	}

	public void setPortada(String portada) {
		this.portada = portada;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ISBN ^ (ISBN >>> 32));
		result = prime * result + ((autor == null) ? 0 : autor.hashCode());
		result = prime * result + ((autorId == null) ? 0 : autorId.hashCode());
		result = prime * result + ((portada == null) ? 0 : portada.hashCode());
		result = prime * result + ((titulo == null) ? 0 : titulo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Libro other = (Libro) obj;
		if (ISBN != other.ISBN)
			return false;
		if (autor == null) {
			if (other.autor != null)
				return false;
		} else if (!autor.equals(other.autor))
			return false;
		if (autorId == null) {
			if (other.autorId != null)
				return false;
		} else if (!autorId.equals(other.autorId))
			return false;
		if (portada == null) {
			if (other.portada != null)
				return false;
		} else if (!portada.equals(other.portada))
			return false;
		if (titulo == null) {
			if (other.titulo != null)
				return false;
		} else if (!titulo.equals(other.titulo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Libro [ISBN=" + ISBN + ", titulo=" + titulo + ", autor=" + autor + ", autorId=" + autorId + ", portada="
				+ portada + "]";
	}

}
