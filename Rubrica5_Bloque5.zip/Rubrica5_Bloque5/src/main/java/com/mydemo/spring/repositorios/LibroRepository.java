package com.mydemo.spring.repositorios;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mydemo.spring.modelo.Autor;
import com.mydemo.spring.modelo.Libro;

public interface LibroRepository extends JpaRepository<Libro, Long> {

	Object findByISBN(long iSBN);

	public void saveAll(List<Libro> list);

	public void save2(Libro libro);

	Object findByTitulo(String titulo);

	void save(Libro libro, Autor autor);

}
