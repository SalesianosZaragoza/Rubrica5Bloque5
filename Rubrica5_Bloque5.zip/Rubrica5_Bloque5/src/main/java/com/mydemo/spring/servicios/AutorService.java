package com.mydemo.spring.servicios;

import java.text.SimpleDateFormat;
import java.util.List;

import com.mydemo.spring.modelo.Autor;

public interface AutorService {

	public Autor add(Autor a);

	public List<Autor> findAll();

	public Autor findById(long id);

	public Autor findByName(String nombre);

	public Autor findByFechaNacimiento(SimpleDateFormat fechaNacimiento);

	public Autor edit(Autor a);

}
