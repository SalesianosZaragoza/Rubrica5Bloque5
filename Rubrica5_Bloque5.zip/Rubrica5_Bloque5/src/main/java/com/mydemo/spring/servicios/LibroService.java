package com.mydemo.spring.servicios;

import java.util.List;

import com.mydemo.spring.modelo.Libro;

public interface LibroService {

	public Libro add(Libro l);

	public List<Libro> findAll();

	public Libro findByISBN(long ISBN);

	public Libro findBytitulo(String titulo);

	public Libro findByAutor(String autor);

	public Libro edit(Libro nuevoLibro);

	void delete(Libro l);

	Libro findById(Long id);

}
