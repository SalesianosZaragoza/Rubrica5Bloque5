package com.mydemo.spring.modelo;

public @interface Date {

}
