package com.mydemo.spring.controladores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import com.mydemo.spring.modelo.Libro;
import com.mydemo.spring.servicios.LibroService;
import com.mydemo.spring.upload.storage.StorageService;

@Controller
public class LibroController {

	@Autowired
	private LibroService servicio;

	@Autowired
	private StorageService storageService;

	@GetMapping({ "/", "/libro/list" })
	public String listado(Model model) {
		model.addAttribute("listaLibros", servicio.findAll());
		return "list";
	}

	@GetMapping("/libro/new")
	public String nuevoLibroForm(Model model) {
		model.addAttribute("libroForm", new Libro());
		return "form";
	}

	@PostMapping("/libro/new/submit")
	public String nuevoLibroSubmit(@Valid @ModelAttribute("libroForm") Libro nuevoLibro, BindingResult bindingResult,
			@RequestParam("file") MultipartFile file) {

		if (bindingResult.hasErrors()) {
			return "form";
		} else {
			if (!file.isEmpty()) {
				String portada = storageService.store(file, nuevoLibro.getISBN());
				nuevoLibro.setPortada(MvcUriComponentsBuilder
						.fromMethodName(LibroController.class, "serveFile", portada).build().toUriString());
			}
			nuevoLibro = servicio.add(nuevoLibro);
			return "redirect:/libro/list";
		}
	}

	@GetMapping("/libro/edit/{id}")
	public String editarLibroForm(@PathVariable long ISBN, Model model) {
		Libro libro = servicio.findByISBN(ISBN);
		if (libro != null) {
			model.addAttribute("libroForm", libro);
			return "form";
		} else
			return "redirect:/libro/new";
	}

	@PostMapping("/libro/edit/submit")
	public String editarLibroSubmit(@Valid @ModelAttribute("libroForm") Libro nuevoLibro, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "form";
		} else {
			nuevoLibro = servicio.edit(nuevoLibro);
			return "redirect:/libro/list";
		}
	}

	@GetMapping("/files/{filename:.+}")
	@ResponseBody
	public ResponseEntity<Resource> serveFile(@PathVariable String filename) {
		Resource file = storageService.loadAsResource(filename);
		return ResponseEntity.ok().body(file);
	}

}
