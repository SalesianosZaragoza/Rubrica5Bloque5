package com.mydemo.spring.repositorios;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mydemo.spring.modelo.Autor;
import com.mydemo.spring.modelo.Libro;

public interface AutorRepository extends JpaRepository<Autor, Long> {

	public void saveAll(List<Autor> list);

	public void save1(Autor autor);

	public void save(Autor autor, Libro libro);

}
