package com.mydemo.spring.servicios;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.mydemo.spring.modelo.Libro;

@Service("libroServiceMemory")
public abstract class LibroServiceMemory implements LibroService {

	private List<Libro> repositorio = new ArrayList<>();

	public Libro add(Libro l) {
		repositorio.add(l);
		return l;
	}

	public List<Libro> findAll() {
		return repositorio;
	}

	public Libro findByISBN(long ISBN) {
		Libro result = null;
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repositorio.size()) {
			if (repositorio.get(i).getISBN() == ISBN) {
				encontrado = true;
				result = repositorio.get(i);
			} else {
				i++;
			}
		}

		return result;
	}

	public Libro findByTitulo(String titulo) {
		Libro result = null;
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repositorio.size()) {
			if (repositorio.get(i).getTitulo() == titulo) {
				encontrado = true;
				result = repositorio.get(i);
			} else {
				i++;
			}
		}

		return result;
	}

	public Libro findByAutor(String autor) {
		Libro result = null;
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repositorio.size()) {
			if (repositorio.get(i).getAutor() == autor) {
				encontrado = true;
				result = repositorio.get(i);
			} else {
				i++;
			}
		}

		return result;
	}

	public Libro edit(Libro l) {
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repositorio.size()) {
			if (repositorio.get(i).getISBN() == l.getISBN()) {
				encontrado = true;
				repositorio.remove(i);
				repositorio.add(i, l);
			} else {
				i++;
			}
		}

		if (!encontrado)
			repositorio.add(l);

		return l;
	}

	public Libro editPorTitulo(Libro l) {
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repositorio.size()) {
			if (repositorio.get(i).getTitulo() == l.getTitulo()) {
				encontrado = true;
				repositorio.remove(i);
				repositorio.add(i, l);
			} else {
				i++;
			}
		}

		if (!encontrado)
			repositorio.add(l);

		return l;
	}

	@PostConstruct
	public void init() {
		// repositorio.addAll(
		// Arrays.asList(new Libro(1012210, "La insustentable Levedad del Ser", "Millan
		// Kundera", null, "portada"),
		// new Libro(10255535, "Pesadillas", "R. L. Stine", null, "portada2"),
		// new Libro(103555226, "La Isla del Tesoro", "Robert Louis Stenvenson", null,
		// "portada3")));
	}

}
