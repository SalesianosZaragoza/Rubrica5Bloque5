package com.mydemo.spring.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.mydemo.spring.modelo.Autor;
import com.mydemo.spring.repositorios.AutorRepository;

@Primary
@Service("autorServiceDB")
public abstract class AutorServiceDB implements AutorService {

	@Autowired
	private AutorRepository repositorio;

	@Override
	public Autor add(Autor a) {
		return repositorio.save(a);
	}

	@Override
	public List<Autor> findAll() {
		return repositorio.findAll();
	}

	@Override
	public Autor findById(long id) {
		return repositorio.findById(id).orElse(null);
	}

	@Override
	public Autor edit(Autor a) {
		return repositorio.save(a);
	}

	public void delete(Autor a) {
		repositorio.delete(a);
	}

}
