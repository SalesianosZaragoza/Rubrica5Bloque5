package com.mydemo.spring.servicios;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.mydemo.spring.modelo.Autor;

@Service("autorServiceMemory")
public abstract class AutorServiceMemory implements AutorService {

	private List<Autor> repositorio = new ArrayList<>();

	public Autor add(Autor a) {
		repositorio.add(a);
		return a;
	}

	public List<Autor> findAll() {
		return repositorio;
	}

	public Autor findById(long id) {
		Autor result = null;
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repositorio.size()) {
			if (repositorio.get(i).getId() == id) {
				encontrado = true;
				result = repositorio.get(i);
			} else {
				i++;
			}
		}

		return result;
	}

	public Autor findByFechaNacimiento(Date fechaNacimiento) {
		Autor result = null;
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repositorio.size()) {
			if (repositorio.get(i).getFechaNacimiento() == fechaNacimiento) {
				encontrado = true;
				result = repositorio.get(i);
			} else {
				i++;
			}
		}

		return result;
	}

	public Autor findByNombre(String nombre) {
		Autor result = null;
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repositorio.size()) {
			if (repositorio.get(i).getNombre() == nombre) {
				encontrado = true;
				result = repositorio.get(i);
			} else {
				i++;
			}
		}

		return result;
	}

	public Autor edit(Autor a) {
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repositorio.size()) {
			if (repositorio.get(i).getId() == a.getId()) {
				encontrado = true;
				repositorio.remove(i);
				repositorio.add(i, a);
			} else {
				i++;
			}
		}

		if (!encontrado)
			repositorio.add(a);

		return a;
	}

	@PostConstruct
	public void init() {
		// repositorio.addAll(
		// Arrays.asList(new Autor(1001, "Millan Kundera", "millankundera@hotmail.com",
		// null, "avatar6.png"),
		// new Autor(1002, "Stephen King", "stephenkind@gmail.com", null,
		// "avatar3.png"),
		// new Autor(1003, "Miguel Delibes", "miguel.delibes@hotmail.com", null,
		// "avatar5.png")));
	}

}
