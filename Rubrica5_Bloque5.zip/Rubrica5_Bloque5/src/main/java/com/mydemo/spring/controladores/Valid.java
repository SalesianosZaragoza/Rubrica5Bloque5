package com.mydemo.spring.controladores;

public @interface Valid {

}
