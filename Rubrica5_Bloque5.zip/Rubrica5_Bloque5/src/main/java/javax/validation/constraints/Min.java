package javax.validation.constraints;

public class Min {

}
